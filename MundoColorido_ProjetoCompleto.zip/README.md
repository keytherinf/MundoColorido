# Mundo Colorido

Aplicativo educativo e acessível para auxiliar crianças com autismo no processo de alfabetização, concentração e aprendizado de formas geométricas.

Criado como projeto de extensão por Ketherin Francisco Alemão.